﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace VehicleAssessmentCapitec.ModelViews
{
    public class VehicleViewModel
    {
        [Key]
        public int vehicle_id { get; set; }

        [Required(ErrorMessage = "Brand is required"), StringLength(20, ErrorMessage = "The {0} value cannot exceed {1} characters. ")]
        public string brand { get; set; }
        
        public string model { get; set; }
        public string make { get; set; }
    }
}
