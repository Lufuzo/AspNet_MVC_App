﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace VehicleAssessmentCapitec.ModelViews
{
    public class CarViewModel : VehicleViewModel
    {
        [Key]
        public int car_Id { get; set; }
        public string car_Registration { get; set; }
    }
}
