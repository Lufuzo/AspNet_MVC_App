﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace VehicleAssessmentCapitec.Models
{
    public class Bike : Vehicle
    {
       // [Key]
        public int bike_Id { get; set; }
        public string description { get; set; }
       // public int vehicle_id { get; set; }
        public Vehicle Vehicle { get; set; }
    }
}
