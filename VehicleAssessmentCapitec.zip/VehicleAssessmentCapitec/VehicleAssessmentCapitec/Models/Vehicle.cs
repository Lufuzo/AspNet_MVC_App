﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace VehicleAssessmentCapitec.Models
{
    public class Vehicle
    {
        [Key]
        public int vehicle_id { get; set; }
        public string brand { get; set; }
        public string model { get; set; }
        public string make { get; set; }

        public ICollection<Bike> Bikes { get; set; }
        public ICollection<Car> Cars { get; set; }
    }
}
