﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleAssessmentCapitec.Models;
using VehicleAssessmentCapitec.ModelViews;
using VehicleAssessmentCapitec.Reposatory;

namespace VehicleAssessmentCapitec.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarsController : ControllerBase
    {
        public readonly ICarReposatory _carReposatory;

        public CarsController(ICarReposatory carReposatory)
        {
            _carReposatory = carReposatory;
        }

        [HttpGet]
        public async Task<IEnumerable<Car>> GetCars()
        {

            return await _carReposatory.GetCar();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Car>> GetCars(int id)
        {

            return await _carReposatory.GetCar(id);
        }

        [HttpPost]
        public async Task<ActionResult<Car>> CreateBook([FromBody] CarViewModel carViewModel)
        {

            if (ModelState.IsValid)
            {
                Car car = new Car();
                car.car_Id = carViewModel.car_Id;
                car.brand = carViewModel.brand;
                car.model = carViewModel.model;
                car.make = carViewModel.make;
                car.car_Registration = carViewModel.car_Registration;

                var newCar = await _carReposatory.CreateCar(car);
                return CreatedAtAction(nameof(GetCars), new { id = newCar.vehicle_id }, newCar);
            }


            return BadRequest("Record inserting is invalid");
        }

        [HttpPut]
        public async Task<ActionResult> UpdateBike(int id, [FromBody] CarViewModel carViewModel)
        {
            Car car = new Car();
            car.car_Id = carViewModel.car_Id;
            car.brand = carViewModel.brand;
            car.model = carViewModel.model;
            car.make = carViewModel.make;
            car.car_Registration = carViewModel.car_Registration;
            if (id != car.car_Id)
            {
                return BadRequest("Record to update not found");

            }
            else
            {
                await _carReposatory.UpdateCar(car);
            }
            return NoContent();
        }


        [HttpDelete]
        public async Task<ActionResult> DeleteCar(int id)
        {

            var carToDelete = _carReposatory.GetCar(id);
            if (carToDelete == null)
            {
                return BadRequest("Record to delete not found");

            }

            await _carReposatory.DeleteCar(carToDelete.Id);
            return NoContent();

        }


    }
}
