﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleAssessmentCapitec.Models;
using VehicleAssessmentCapitec.ModelViews;
using VehicleAssessmentCapitec.Reposatory;

namespace VehicleAssessmentCapitec.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehiclesController : ControllerBase
    {
        public readonly IVehicleReposatory _vehicleReposatory;

        public VehiclesController(IVehicleReposatory vehicleReposatory)
        {
            _vehicleReposatory = vehicleReposatory;
        }

        [HttpGet]
        public async Task<IEnumerable<Vehicle>> GetVehicles()
        {

            return await _vehicleReposatory.GetVehicles();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Vehicle>> GetVehicle(int id)
        {

            return await _vehicleReposatory.GetVehicle(id);
        }

        [HttpPost]
        public async Task<ActionResult<Vehicle>> CreateVehicle([FromBody] VehicleViewModel vehicleViewModel)
        {

            if (ModelState.IsValid)
            {
                Vehicle vehicle = new Vehicle();
                vehicle.vehicle_id = vehicleViewModel.vehicle_id;
                vehicle.brand = vehicleViewModel.brand;
                vehicle.model = vehicle.model;

                var newVehicle = await _vehicleReposatory.CreateVehicle(vehicle);
                return CreatedAtAction(nameof(GetVehicles), new { id = newVehicle.vehicle_id }, newVehicle);
            }


            return BadRequest("Record inserting is invalid");
        }

        [HttpPut]
        public async Task<ActionResult> UpdateVehicle(int id, [FromBody] VehicleViewModel vehicleViewModel)
        {
            Vehicle vehicle = new Vehicle();
            vehicle.vehicle_id = vehicleViewModel.vehicle_id;
            vehicle.vehicle_id = vehicleViewModel.vehicle_id;
            vehicle.brand = vehicleViewModel.brand;
            vehicle.model = vehicle.model;


            if (id != vehicle.vehicle_id)
            {
                return BadRequest("Record to update not found");

            }
            else
            {
                await _vehicleReposatory.UpdateVehicle(vehicle);
            }
            return NoContent();
        }

        [HttpDelete]
        public async Task<ActionResult> DeleteVehicle(int id)
        {

            var vehicleToDelete = _vehicleReposatory.GetVehicle(id);
            if (vehicleToDelete == null)
            {
                return BadRequest("Record to delete not found");

            }

            await _vehicleReposatory.DeleteVehicle(vehicleToDelete.Id);
            return NoContent();

        }

    }
}
