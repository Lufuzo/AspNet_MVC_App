﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleAssessmentCapitec.Models;
using VehicleAssessmentCapitec.ModelViews;
using VehicleAssessmentCapitec.Reposatory;

namespace VehicleAssessmentCapitec.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BikesController : ControllerBase
    {
        public readonly IBikeReposatory _bikeReposatory;

        public BikesController(IBikeReposatory bikeReposatory)
        {
            _bikeReposatory = bikeReposatory;
        }

        [HttpGet]
        public async Task<IEnumerable<Bike>> GetBikes()
        {

            return await _bikeReposatory.GetBike();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Bike>> GetBikes(int id)
        {

            return await _bikeReposatory.GetBike(id);
        }

        [HttpPost]
        public async Task<ActionResult<Bike>> CreateBook([FromBody] BikeViewModel bikeViewModel)
        {
           
            if (ModelState.IsValid)
            {
                Bike bike = new Bike();
                bike.bike_Id = bikeViewModel.bike_Id;
                bike.brand = bikeViewModel.brand;
                bike.model = bikeViewModel.model;
                bike.make = bikeViewModel.make;
                bike.description = bikeViewModel.description;

                var newBike = await _bikeReposatory.CreateBike(bike);
                return CreatedAtAction(nameof(GetBikes), new { id = newBike.vehicle_id }, newBike);
            }
         

            return BadRequest("Record inserting is invalid");
        }

        [HttpPut]
        public async Task<ActionResult> UpdateBike(int id, [FromBody] BikeViewModel bikeViewModel) 
        {
            Bike bike = new Bike();
            bike.bike_Id = bikeViewModel.bike_Id;
            bike.brand = bikeViewModel.brand;
            bike.model = bikeViewModel.model;
            bike.make = bikeViewModel.make;
            bike.description = bikeViewModel.description;
            if (id != bike.bike_Id)
            {
                return BadRequest("Record to update not found");

            }
            else
            {
               await _bikeReposatory.UpdateBike(bike);
            }
            return NoContent();
        }


        [HttpDelete]
        public async Task<ActionResult> DeleBike(int id)
        {

            var bikeToDelete = _bikeReposatory.GetBike(id);
            if (bikeToDelete == null)
            {
                return BadRequest("Record to delete not found");

            }

            await _bikeReposatory.DeleteBike(bikeToDelete.Id);
            return NoContent();
  
        }

    }
}
