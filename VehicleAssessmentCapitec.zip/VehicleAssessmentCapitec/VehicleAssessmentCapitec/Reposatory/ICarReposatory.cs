﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleAssessmentCapitec.Models;

namespace VehicleAssessmentCapitec.Reposatory
{
    public interface ICarReposatory
    {
        Task<IEnumerable<Car>> GetCar();
        Task<Car> GetCar(int id);
        Task<Car> CreateCar(Car car);

        Task UpdateCar(Car Car);
        Task DeleteCar(int id);
    }
}
