﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleAssessmentCapitec.Models;

namespace VehicleAssessmentCapitec.Reposatory
{
    public interface IBikeReposatory
    {
        Task<IEnumerable<Bike>> GetBike();
        Task<Bike> GetBike(int id);
        Task<Bike> CreateBike(Bike bike);

        Task UpdateBike(Bike bike);
        Task DeleteBike(int id);


    }
}
