﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleAssessmentCapitec.Domain;
using VehicleAssessmentCapitec.Models;

namespace VehicleAssessmentCapitec.Reposatory
{
    public class CarReposatory : ICarReposatory
    {
        public readonly CarContext _carContext;


        public CarReposatory(CarContext carContext)
        {
            _carContext = carContext;
        }


        public async Task<Car> CreateCar(Car car)
        {

            _carContext.Cars.Add(car);
            await _carContext.SaveChangesAsync();
            return car;
        }

        public async Task DeleteCar(int id)
        {
            var carToDelete = await _carContext.Cars.FindAsync(id);
            _carContext.Cars.Remove(carToDelete);
            await _carContext.SaveChangesAsync();
        }

        public async Task<IEnumerable<Car>> GetCar()
        {
            return await _carContext.Cars.ToListAsync();
        }

        public async Task<Car> GetCar(int id)
        {
            return await _carContext.Cars.FindAsync(id);
        }

        public async Task UpdateCar(Car car)
        {
            _carContext.Entry(car).State = EntityState.Modified;
            await _carContext.SaveChangesAsync();
        }
    }
}
