﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleAssessmentCapitec.Models;

namespace VehicleAssessmentCapitec.Reposatory
{
    public interface IVehicleReposatory
    {

        Task<IEnumerable<Vehicle>> GetVehicles();
        Task<Vehicle> GetVehicle(int id);
        Task<Vehicle> CreateVehicle(Vehicle vehicle);

        Task UpdateVehicle(Vehicle vehicle);
        Task DeleteVehicle(int id);
    }
}
