﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleAssessmentCapitec.Domain;
using VehicleAssessmentCapitec.Models;

namespace VehicleAssessmentCapitec.Reposatory
{
    public class VehicleReposatory : IVehicleReposatory
    {

        public readonly VehicleContext _vehicleContext;


        public VehicleReposatory(VehicleContext vehicleContext)
        {
            _vehicleContext = vehicleContext;
        }
        public async Task<Vehicle> CreateVehicle(Vehicle vehicle)
        {

            _vehicleContext.Vehicles.Add(vehicle);
            await _vehicleContext.SaveChangesAsync();
            return vehicle;
        }

        public  async Task DeleteVehicle(int id)
        {
            var vehicleToDelete = await _vehicleContext.Vehicles.FindAsync(id);
            _vehicleContext.Vehicles.Remove(vehicleToDelete);
            await _vehicleContext.SaveChangesAsync();
        }

        public async Task<Vehicle> GetVehicle(int id)
        {
            return await _vehicleContext.Vehicles.FindAsync(id);
        }

        public async Task<IEnumerable<Vehicle>> GetVehicles()
        {
            return await _vehicleContext.Vehicles.ToListAsync();
        }

        public async Task UpdateVehicle(Vehicle vehicle)
        {
            _vehicleContext.Entry(vehicle).State = EntityState.Modified;
            await _vehicleContext.SaveChangesAsync();
        }
    }
}
