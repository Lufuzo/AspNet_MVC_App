﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleAssessmentCapitec.Domain;
using VehicleAssessmentCapitec.Models;

namespace VehicleAssessmentCapitec.Reposatory
{
    public class BikeReposatory : IBikeReposatory
    {

        public readonly BikeContext _bikeContext;


        public BikeReposatory(BikeContext bikeContext)
        {
            _bikeContext = bikeContext;
        }


        public async Task<Bike> CreateBike(Bike bike)
        {

            _bikeContext.Bikes.Add(bike);
            await _bikeContext.SaveChangesAsync();
            return bike;
        }

        public async Task DeleteBike(int id)
        {
            var bikeToDelete = await _bikeContext.Bikes.FindAsync(id);
            _bikeContext.Bikes.Remove(bikeToDelete);
            await _bikeContext.SaveChangesAsync();
        }

        public async Task<IEnumerable<Bike>> GetBike()
        {
            return await _bikeContext.Bikes.ToListAsync();
        }

        public async Task<Bike> GetBike(int id)
        {
            return await _bikeContext.Bikes.FindAsync(id);
        }

        public async Task UpdateBike(Bike bike)
        {
            _bikeContext.Entry(bike).State = EntityState.Modified;
            await _bikeContext.SaveChangesAsync();
        }
    }
}
