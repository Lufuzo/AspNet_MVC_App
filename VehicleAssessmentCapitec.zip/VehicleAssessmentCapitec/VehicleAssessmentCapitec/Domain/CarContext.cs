﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VehicleAssessmentCapitec.Models;

namespace VehicleAssessmentCapitec.Domain
{
    public class CarContext : DbContext
    {
        public CarContext(DbContextOptions<CarContext> options)
                : base(options)
        {
            Database.EnsureCreated();
        }

       public DbSet<Car> Cars { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Vehicle>()
                .HasMany(c => c.Bikes)
                .WithOne(e => e.Vehicle);
        }
    }
}
