﻿using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VehicleAssessmentCapitec.Controllers;
using VehicleAssessmentCapitec.Domain;
using VehicleAssessmentCapitec.Models;
using VehicleAssessmentCapitec.ModelViews;
using VehicleAssessmentCapitec.Reposatory;
using Xunit;

namespace VehicleAssessmentTestProject
{
    public class VehicleUnitTestController
    {
        private static VehicleReposatory vehicleRepository;
        
        public static DbContextOptions<VehicleContext> dbContextOptions { get; }
        public static string connectionString = "Data source = Vehicle;";

         static VehicleUnitTestController()
        {
            dbContextOptions = new DbContextOptionsBuilder<VehicleContext>()
                .UseSqlite(connectionString)
                .Options;

            var contextV = new VehicleContext(dbContextOptions);
            VehicleInitializer db = new VehicleInitializer();
            db.TestMethod(contextV);

           vehicleRepository = new VehicleReposatory(contextV);


        }

        [Fact]
        public async void GetVehicleById_OkResult()
        {
            //Arrange  
            var controller = new VehiclesController(vehicleRepository);
            var vehicleId = 2;

            //Act  
            var data = await controller.GetVehicle(vehicleId);

            //Assert  
             Assert.IsType<OkObjectResult>(data);
         
        }

        [Fact]
        public async void CreateVehicleData_OkResult()
        {
            //Arrange  
            var controller = new VehiclesController(vehicleRepository);
            var vehicleViewModel = new VehicleViewModel() { vehicle_id = 1, model = "XA 114", brand = "Test", make = "TestMake" };

            //Act  
            var data = await controller.CreateVehicle(vehicleViewModel);

            //Assert  
            Assert.IsType<OkObjectResult>(data);
        }

        [Fact]
        public async void UpdateVehicle_Return_OkResult()
        {
            //Arrange  
            var controller = new VehiclesController(vehicleRepository);
            var vehicleId = 2;

            //Act  
            var existingPost = await controller.GetVehicle(vehicleId);
            var okResult = existingPost.Should().BeOfType<OkObjectResult>().Subject;
            var result = okResult.Value.Should().BeAssignableTo<VehicleViewModel>().Subject;

            var vehicleViewModel = new VehicleViewModel();
            vehicleViewModel.model = result.model;
            vehicleViewModel.make = result.make;
            vehicleViewModel.vehicle_id = result.vehicle_id;
            vehicleViewModel.brand = result.brand;

            var updatedData = await controller.UpdateVehicle(vehicleViewModel.vehicle_id,vehicleViewModel);

            //Assert  
            Assert.IsType<OkResult>(updatedData);
        }

        [Fact]
        public async void DeleteVehicle_Return_OkResult()
        {
            //Arrange  
            var controller = new VehiclesController(vehicleRepository);
            var postId = 2;

            //Act  
            var data = await controller.DeleteVehicle(postId);

            //Assert  
            Assert.IsType<OkResult>(data);
        }

    }
}
