﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

using VehicleAssessmentCapitec.Domain;
using VehicleAssessmentCapitec.Models;

namespace VehicleAssessmentTestProject
{
    public class VehicleInitializer
    {
        public VehicleInitializer()
        {
        }

        public void TestMethod(VehicleContext context)
        {
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            context.Vehicles.AddRange(
                new Vehicle() { vehicle_id = 1, model = "XA 114", brand = "Test", make = "TestMake"},
                new Vehicle() { vehicle_id = 1, model = "XA 114", brand = "Test", make = "TestMake" }
            );

            context.SaveChanges();
        }

        public void Bike(BikeContext context)
        {
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            context.Bikes.AddRange(
                new Bike() { bike_Id = 1, description = "aa", brand = "Test", make = "TestMake", model = "TestModel", vehicle_id = 1 },
                new Bike() { bike_Id = 1, description = "aa", brand = "Test", make = "TestMake", model = "TestModel", vehicle_id = 1 }
            );

            context.SaveChanges();
        }
        public void Car(CarContext context)
        {
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            context.Cars.AddRange(
                new Car() { car_Id = 1, car_Registration = "XA 114", brand = "Test", make = "TestMake", model = "TestModel", vehicle_id = 1 },
                new Car() { car_Id = 1, car_Registration = "Ca 44", brand = "Test", make = "TestMake", model = "TestModel", vehicle_id = 1 }
            );

            context.SaveChanges();
        }
    }
}
